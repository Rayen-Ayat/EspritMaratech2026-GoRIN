export enum MessageRole {
  USER = 'user',
  MODEL = 'model',
}

export enum MessageType {
  TEXT = 'text',
  AUDIO = 'audio',
  VIDEO = 'video',
  SIGN_GLOSS = 'sign_gloss',
}

export interface ChatMessage {
  id: string;
  role: MessageRole;
  type: MessageType;
  content: string; // The text content or base64 data
  translation?: string; // The translated text or gloss
  timestamp: number;
}

export enum AppMode {
  HEARING_TO_DEAF = 'HEARING_TO_DEAF', // User speaks/types -> Avatar Signs
  DEAF_TO_HEARING = 'DEAF_TO_HEARING', // User signs (video) -> App Speaks/Text
}

export interface SignGlossResponse {
  gloss: string[]; // Array of sign words
  description: string; // Description of movements for the avatar
  tunisianText: string;
  mood?: 'neutral' | 'happy' | 'questioning' | 'concerned';
}
