import React, { useState } from 'react';
import { translations, Language } from '../utils/translations';
import { ArrowLeft, ArrowRight } from 'lucide-react';

interface AuthProps {
  lang: Language;
  onLogin: () => void;
  onBack: () => void;
}

const Auth: React.FC<AuthProps> = ({ lang, onLogin, onBack }) => {
  const [isLogin, setIsLogin] = useState(true);
  const t = translations[lang];
  const isRTL = lang === 'ar';

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Mock authentication
    onLogin();
  };

  return (
    <div className="flex-1 flex flex-col items-center justify-center p-6 w-full max-w-lg mx-auto animate-fade-in">
      
      <button 
        onClick={onBack}
        className="self-start mb-6 p-2 text-stone-600 hover:text-red-700 transition-colors"
      >
         {isRTL ? <ArrowRight size={32} /> : <ArrowLeft size={32} />}
      </button>

      <div className="bg-white p-8 rounded-[2.5rem] shadow-xl border-2 border-stone-200 w-full">
        <h2 className="text-4xl font-black text-center text-red-800 mb-8">
          {isLogin ? t.login : t.signup}
        </h2>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <label className="text-xl font-bold text-stone-700 block text-start">{t.email}</label>
            <input 
              type="email" 
              required
              className="w-full px-6 py-4 rounded-xl bg-stone-50 border-2 border-stone-200 focus:border-red-600 focus:outline-none text-xl font-medium text-stone-900 transition-all"
            />
          </div>

          <div className="space-y-2">
            <label className="text-xl font-bold text-stone-700 block text-start">{t.password}</label>
            <input 
              type="password" 
              required
              className="w-full px-6 py-4 rounded-xl bg-stone-50 border-2 border-stone-200 focus:border-red-600 focus:outline-none text-xl font-medium text-stone-900 transition-all"
            />
          </div>

          <button 
            type="submit"
            className="w-full bg-red-700 hover:bg-red-800 text-white text-2xl font-bold py-5 rounded-xl shadow-lg mt-4 transition-all"
          >
            {isLogin ? t.submit : t.createAccount}
          </button>
        </form>

        <div className="mt-8 text-center pt-6 border-t border-stone-100">
          <p className="text-lg text-stone-600 font-medium mb-3">
            {isLogin ? t.dontHaveAccount : t.haveAccount}
          </p>
          <button 
            onClick={() => setIsLogin(!isLogin)}
            className="text-red-700 font-bold text-xl hover:underline"
          >
            {isLogin ? t.signup : t.login}
          </button>
        </div>
      </div>
    </div>
  );
};

export default Auth;