import React, { useState, useRef, useEffect } from 'react';
import { Mic, Video, Send, RefreshCw, Camera, User, Ear, RotateCcw, LogOut } from 'lucide-react';
import Avatar from './Avatar';
import { 
  transcribeAudio, 
  translateToSignGloss, 
  interpretSignVideo, 
  generateSpeech 
} from '../services/geminiService';
import { AppMode, ChatMessage, MessageRole, MessageType } from '../types';
import { translations, Language } from '../utils/translations';

interface MainAppProps {
  lang: Language;
  onLogout: () => void;
}

function MainApp({ lang, onLogout }: MainAppProps) {
  const t = translations[lang];
  const isRTL = lang === 'ar';

  const [mode, setMode] = useState<AppMode>(AppMode.HEARING_TO_DEAF);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputText, setInputText] = useState("");
  const [isRecording, setIsRecording] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  
  // Avatar State
  const [avatarState, setAvatarState] = useState<'idle' | 'listening' | 'signing' | 'thinking'>('idle');
  const [currentGloss, setCurrentGloss] = useState<string[]>([]);
  const [currentMood, setCurrentMood] = useState<'neutral' | 'happy' | 'questioning' | 'concerned'>('neutral');
  
  // Replay State
  const [lastGloss, setLastGloss] = useState<string[]>([]);
  const [lastMood, setLastMood] = useState<'neutral' | 'happy' | 'questioning' | 'concerned'>('neutral');
  
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const animationTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Auto-scroll to bottom of chat
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, currentGloss]);

  const handleModeToggle = () => {
    setMode(prev => prev === AppMode.HEARING_TO_DEAF ? AppMode.DEAF_TO_HEARING : AppMode.HEARING_TO_DEAF);
    setMessages([]);
    setAvatarState('idle');
    setCurrentGloss([]);
    setCurrentMood('neutral');
    setLastGloss([]); 
  };

  const triggerAvatarAnimation = (gloss: string[], mood: 'neutral' | 'happy' | 'questioning' | 'concerned') => {
    if (animationTimeoutRef.current) {
      clearTimeout(animationTimeoutRef.current);
    }

    setCurrentGloss(gloss);
    setCurrentMood(mood);
    setAvatarState('signing');
    
    const animationDuration = Math.max(2000, gloss.length * 1200);
    
    animationTimeoutRef.current = setTimeout(() => {
      setAvatarState('idle');
      setCurrentGloss([]);
      setCurrentMood('neutral');
    }, animationDuration);
  };

  const handleReplay = () => {
    if (lastGloss.length > 0) {
      triggerAvatarAnimation(lastGloss, lastMood);
    }
  };

  // --- Hearing Mode Functions ---

  const handleTextSubmit = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!inputText.trim()) return;

    const text = inputText;
    setInputText("");
    addMessage(MessageRole.USER, MessageType.TEXT, text);
    
    await processHearingInput(text);
  };

  const startAudioRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      mediaRecorderRef.current = recorder;
      audioChunksRef.current = [];

      recorder.ondataavailable = (event) => {
        if (event.data.size > 0) audioChunksRef.current.push(event.data);
      };

      recorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const reader = new FileReader();
        reader.readAsDataURL(audioBlob);
        reader.onloadend = async () => {
          const base64Audio = (reader.result as string).split(',')[1];
          await processAudioInput(base64Audio, audioBlob.type);
        };
        stream.getTracks().forEach(track => track.stop());
      };

      recorder.start();
      setIsRecording(true);
      setAvatarState('listening');
    } catch (err) {
      console.error("Error accessing microphone:", err);
      alert("Could not access microphone.");
    }
  };

  const stopAudioRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      setAvatarState('thinking');
    }
  };

  const processAudioInput = async (base64Audio: string, mimeType: string) => {
    setIsProcessing(true);
    try {
      const text = await transcribeAudio(base64Audio, mimeType);
      addMessage(MessageRole.USER, MessageType.AUDIO, t.audioInput, text);
      await processHearingInput(text);
    } catch (error) {
      console.error(error);
      addMessage(MessageRole.MODEL, MessageType.TEXT, t.sorryAudio);
      setAvatarState('idle');
    } finally {
      setIsProcessing(false);
    }
  };

  const processHearingInput = async (text: string) => {
    setAvatarState('thinking');
    setIsProcessing(true);
    try {
      const result = await translateToSignGloss(text);
      addMessage(MessageRole.MODEL, MessageType.SIGN_GLOSS, result.description, undefined, result.gloss.join(" -> "));
      setLastGloss(result.gloss);
      setLastMood(result.mood || 'neutral');
      triggerAvatarAnimation(result.gloss, result.mood || 'neutral');
    } catch (error) {
      console.error(error);
      setAvatarState('idle');
    } finally {
      setIsProcessing(false);
    }
  };

  // --- Deaf Mode Functions ---

  const handleVideoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64Video = (reader.result as string).split(',')[1];
        await processSignVideo(base64Video, file.type);
      };
      reader.readAsDataURL(file);
    }
  };

  const processSignVideo = async (base64Video: string, mimeType: string) => {
    setIsProcessing(true);
    setAvatarState('thinking');
    addMessage(MessageRole.USER, MessageType.VIDEO, t.videoSent);

    try {
      const translation = await interpretSignVideo(base64Video, mimeType);
      const audioBase64 = await generateSpeech(translation);
      addMessage(MessageRole.MODEL, MessageType.TEXT, translation);
      if (audioBase64) {
        playAudio(audioBase64);
      }
      setAvatarState('idle');
    } catch (error) {
      console.error(error);
      addMessage(MessageRole.MODEL, MessageType.TEXT, t.failedInterpret);
      setAvatarState('idle');
    } finally {
      setIsProcessing(false);
    }
  };

  const playAudio = (base64Audio: string) => {
    try {
      const audio = new Audio(`data:audio/mp3;base64,${base64Audio}`);
      audio.play();
    } catch (e) {
      console.error("Audio play error", e);
    }
  };

  const addMessage = (role: MessageRole, type: MessageType, content: string, translation?: string, gloss?: string) => {
    setMessages(prev => [...prev, {
      id: Date.now().toString(),
      role,
      type,
      content,
      translation: translation || gloss,
      timestamp: Date.now()
    }]);
  };

  return (
    <div className="flex flex-col h-full w-full bg-[#FFF8F0] text-stone-900 font-sans overflow-hidden">
      
      {/* Header */}
      <header className="bg-white/95 backdrop-blur-md border-b-2 border-stone-200 px-6 py-4 flex items-center justify-between shadow-sm z-30 relative shrink-0">
        <div className="flex items-center space-x-3 space-x-reverse">
          <div className="w-12 h-12 rounded-full bg-red-700 flex items-center justify-center text-white font-black text-xl shadow-sm border-2 border-red-800" aria-hidden="true">
             {lang === 'ar' ? 'م' : 'M'}
          </div>
          <h1 className={`text-3xl font-black text-red-800 tracking-tight leading-none ${isRTL ? 'mr-3' : 'ml-3'}`}>{t.appName}</h1>
        </div>
        
        <div className="flex items-center space-x-2">
            <button 
            onClick={handleModeToggle}
            className={`flex items-center space-x-2 px-4 py-2 rounded-full text-base font-bold transition-all shadow-md border-2 ${
                mode === AppMode.HEARING_TO_DEAF 
                ? 'bg-blue-50 text-blue-900 border-blue-400 hover:bg-blue-100' 
                : 'bg-green-50 text-green-900 border-green-400 hover:bg-green-100'
            }`}
            dir={isRTL ? 'rtl' : 'ltr'}
            >
            {mode === AppMode.HEARING_TO_DEAF ? (
                <>
                <Ear size={20} aria-hidden="true" />
                <span className={isRTL ? 'mr-2' : 'ml-2'}>{t.hearingMode}</span>
                </>
            ) : (
                <>
                <User size={20} aria-hidden="true" />
                <span className={isRTL ? 'mr-2' : 'ml-2'}>{t.deafMode}</span>
                </>
            )}
            <RefreshCw size={16} className={`opacity-80 ${isRTL ? 'mr-1' : 'ml-1'}`} aria-hidden="true" />
            </button>
            <button onClick={onLogout} className="p-2 text-stone-500 hover:text-red-700">
                <LogOut size={24} className={isRTL ? 'rotate-180' : ''}/>
            </button>
        </div>
      </header>

      {/* Avatar Area - Fixed height (approx 1/3 of view) */}
      <div className="w-full bg-[#FFF8F0] border-b-2 border-stone-200 relative z-20 shrink-0 h-[35vh] min-h-[250px] flex items-center justify-center">
         <div className="w-full h-full max-w-2xl">
             <Avatar state={avatarState} gloss={currentGloss} mood={currentMood} />
         </div>
         
         {mode === AppMode.HEARING_TO_DEAF && lastGloss.length > 0 && (
           <button 
             onClick={handleReplay}
             disabled={avatarState === 'signing'}
             className={`absolute bottom-5 p-4 bg-white text-stone-900 rounded-full shadow-xl border-2 border-stone-300 hover:bg-stone-50 transition-all ${isRTL ? 'left-5' : 'right-5'}`}
             title={t.replay}
           >
             <RotateCcw size={28} className={avatarState === 'signing' ? 'animate-spin-reverse' : ''} aria-hidden="true" />
           </button>
         )}
      </div>

      {/* Chat Area - Takes remaining space */}
      <main className="flex-1 overflow-y-auto p-5 space-y-6 no-scrollbar pb-36 bg-[#FFF8F0]" role="log" aria-live="polite">
        <div className="space-y-6 max-w-2xl mx-auto w-full">
          {messages.length === 0 && (
            <div className="text-center text-stone-900 py-10 font-medium opacity-60">
               <p className="text-2xl">{mode === AppMode.HEARING_TO_DEAF ? t.welcomeMessage : t.welcomeMessageDeaf}</p>
            </div>
          )}

          {messages.map((msg) => (
            <div 
              key={msg.id} 
              className={`flex flex-col ${msg.role === MessageRole.USER ? (isRTL ? 'items-start' : 'items-end') : (isRTL ? 'items-end' : 'items-start')}`}
            >
              <div 
                className={`max-w-[95%] px-6 py-4 rounded-[2rem] shadow-md border-2 ${
                  msg.role === MessageRole.USER 
                    ? 'bg-red-700 text-white border-red-800' 
                    : 'bg-white text-stone-900 border-stone-300'
                }`}
              >
                {msg.type === MessageType.VIDEO ? (
                  <div className="flex items-center space-x-3">
                    <Video size={24} aria-hidden="true" />
                    <span className="text-xl font-bold">{t.videoSent}</span>
                  </div>
                ) : (
                   <p className="text-2xl leading-snug font-bold text-start">{msg.content}</p>
                )}

                {msg.translation && (
                  <div className={`mt-3 pt-3 border-t-2 ${msg.role === MessageRole.USER ? 'border-red-400' : 'border-stone-200'}`}>
                    <p className={`text-sm font-black uppercase tracking-widest text-start ${msg.role === MessageRole.USER ? 'text-red-100' : 'text-stone-600'}`}>
                      {msg.role === MessageRole.USER && msg.type === MessageType.AUDIO ? t.transcribed : t.interpretation}
                    </p>
                    <p className={`text-xl italic mt-1 font-bold text-start ${msg.role === MessageRole.USER ? 'text-white' : 'text-stone-900'}`}>{msg.translation}</p>
                  </div>
                )}
              </div>
            </div>
          ))}
          
          {isProcessing && (
             <div className="flex items-center space-x-3 text-stone-800 px-4 animate-pulse font-bold text-xl justify-center">
                <span>{t.translating}</span>
                <div className="flex space-x-1">
                   <div className="w-3 h-3 bg-stone-800 rounded-full animate-bounce"></div>
                   <div className="w-3 h-3 bg-stone-800 rounded-full animate-bounce delay-75"></div>
                   <div className="w-3 h-3 bg-stone-800 rounded-full animate-bounce delay-150"></div>
                </div>
             </div>
          )}
          <div ref={chatEndRef} />
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t-2 border-stone-200 p-5 pb-safe sticky bottom-0 z-30 shadow-[0_-8px_16px_-4px_rgba(0,0,0,0.1)] shrink-0">
        <div className="max-w-2xl mx-auto flex items-center space-x-4">
          
          {mode === AppMode.HEARING_TO_DEAF ? (
            <>
              <form onSubmit={handleTextSubmit} className="flex-1 relative">
                <input
                  type="text"
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  placeholder={t.typePlaceholder}
                  className={`w-full bg-white text-stone-900 placeholder-stone-500 text-xl font-bold rounded-full py-5 focus:outline-none focus:ring-4 focus:ring-red-600 transition-all border-2 border-stone-300 shadow-md ${isRTL ? 'pl-20 pr-8' : 'pl-8 pr-20'}`}
                  disabled={isRecording || isProcessing}
                />
                <button 
                  type="submit" 
                  disabled={!inputText.trim() || isProcessing}
                  className={`absolute top-1/2 -translate-y-1/2 p-3 bg-red-700 text-white rounded-full hover:bg-red-800 disabled:bg-stone-300 disabled:text-stone-500 transition-colors focus:outline-none focus:ring-4 focus:ring-offset-2 focus:ring-red-600 shadow-sm ${isRTL ? 'left-3' : 'right-3'}`}
                >
                  <Send size={24} className={isRTL ? 'rotate-180' : ''} />
                </button>
              </form>

              <button
                onMouseDown={startAudioRecording}
                onMouseUp={stopAudioRecording}
                onTouchStart={startAudioRecording}
                onTouchEnd={stopAudioRecording}
                disabled={isProcessing}
                className={`p-5 rounded-full transition-all duration-200 focus:outline-none focus:ring-4 focus:ring-offset-2 focus:ring-red-600 shadow-md ${
                  isRecording 
                    ? 'bg-red-100 text-red-800 scale-110 ring-4 ring-red-100' 
                    : 'bg-stone-100 text-stone-800 hover:bg-stone-200 border-2 border-stone-300'
                }`}
              >
                <Mic size={32} className={isRecording ? 'animate-pulse' : ''} />
              </button>
            </>
          ) : (
            <>
               <div className="flex-1 text-xl text-stone-700 text-center italic font-bold">
                 {t.captureHint}
               </div>
               
               <input 
                 type="file" 
                 ref={fileInputRef} 
                 accept="video/*" 
                 capture="environment"
                 className="hidden" 
                 onChange={handleVideoUpload}
               />

               <button
                 onClick={() => fileInputRef.current?.click()}
                 disabled={isProcessing}
                 className="flex-1 bg-gradient-to-r from-red-700 to-red-600 text-white rounded-full py-5 px-8 flex items-center justify-center space-x-3 shadow-xl hover:shadow-2xl active:scale-95 transition-all focus:outline-none focus:ring-4 focus:ring-offset-2 focus:ring-red-700 border-2 border-red-800"
               >
                 <Camera size={28} />
                 <span className={`font-black text-xl ${isRTL ? 'mr-3' : 'ml-3'}`}>{t.videoAnalysis}</span>
               </button>
            </>
          )}

        </div>
      </footer>
    </div>
  );
}

export default MainApp;