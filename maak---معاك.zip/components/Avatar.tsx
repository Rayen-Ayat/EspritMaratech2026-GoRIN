import React, { useEffect, useState, useRef, useMemo } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { ContactShadows, Float, RoundedBox } from '@react-three/drei';
import * as THREE from 'three';

// Manually declare JSX intrinsic elements for React Three Fiber to fix TypeScript errors
declare global {
  namespace JSX {
    interface IntrinsicElements {
      group: any;
      mesh: any;
      boxGeometry: any;
      meshStandardMaterial: any;
      capsuleGeometry: any;
      sphereGeometry: any;
      cylinderGeometry: any;
      torusGeometry: any;
      circleGeometry: any;
      meshBasicMaterial: any;
      ambientLight: any;
      hemisphereLight: any;
      spotLight: any;
      pointLight: any;
    }
  }
}

interface AvatarProps {
  state: 'idle' | 'listening' | 'signing' | 'thinking';
  gloss?: string[];
  mood?: 'neutral' | 'happy' | 'questioning' | 'concerned';
}

// --- 3D Pose Interfaces ---
interface JointRotations {
  rightArm: [number, number, number];
  rightForeArm: [number, number, number];
  rightHand: [number, number, number];
  leftArm: [number, number, number];
  leftForeArm: [number, number, number];
  leftHand: [number, number, number];
  head: [number, number, number];
}

const DEFAULT_ROTATION: [number, number, number] = [0, 0, 0];

const createPose = (overrides: Partial<JointRotations>): JointRotations => ({
  rightArm: DEFAULT_ROTATION,
  rightForeArm: DEFAULT_ROTATION,
  rightHand: DEFAULT_ROTATION,
  leftArm: DEFAULT_ROTATION,
  leftForeArm: DEFAULT_ROTATION,
  leftHand: DEFAULT_ROTATION,
  head: DEFAULT_ROTATION,
  ...overrides
});

const POSES_3D: Record<string, JointRotations> = {
  IDLE: createPose({
    rightArm: [0, 0, -0.2],
    rightForeArm: [-0.1, 0, 0],
    rightHand: [0, 0, 0],
    leftArm: [0, 0, 0.2],
    leftForeArm: [-0.1, 0, 0],
    leftHand: [0, 0, 0],
    head: [0, 0, 0],
  }),
  HELLO: createPose({
    rightArm: [0, 0, -2.5],
    rightForeArm: [-0.5, 0, -0.5],
    rightHand: [0, 0, -0.5], // Palm forward
    leftArm: [0, 0, 0.15],
    head: [0, 0.1, 0.05],
  }),
  YOU: createPose({
    rightArm: [-1.4, 0.2, -0.2], 
    rightForeArm: [0, 0, 0], 
    rightHand: [0, 1.5, 0], // Pointing forward
    leftArm: [0, 0, 0.15],
    head: [0, 0, 0],
  }),
  ME: createPose({
    rightArm: [-1.0, 0.5, -0.5], 
    rightForeArm: [-1.8, 0, 0], 
    rightHand: [0, -0.5, 0], // Pointing to chest
    leftArm: [0, 0, 0.15],
    head: [0, 0, 0],
  }),
  YES: createPose({
    rightArm: [-0.8, 0, -0.4],
    rightForeArm: [-1.5, 0, 0],
    rightHand: [0.5, 0, 0], // Fistish
    leftArm: [0, 0, 0.15],
    head: [0.35, 0, 0], 
  }),
  NO: createPose({
    rightArm: [0, 0, -0.2],
    rightForeArm: [-0.5, 0, 0],
    rightHand: [0, 0, 0.5], // Palm out/down
    leftArm: [0, 0, 0.2],
    leftForeArm: [-0.5, 0, 0],
    leftHand: [0, 0, -0.5],
    head: [0, 0.5, 0], 
  }),
  GOOD: createPose({
    rightArm: [-0.5, 0.5, -0.5],
    rightForeArm: [-2.0, 0, 0], 
    rightHand: [0.2, 0, 0], // Thumbs up approximation
    leftArm: [0, 0, 0.15],
    head: [-0.1, 0, 0],
  }),
  QUESTION: createPose({
    rightArm: [0, 0, -0.6], 
    rightForeArm: [-1.5, 0, -0.5], 
    rightHand: [0, 0, -1.0], // Palm up/shrug
    leftArm: [0, 0, 0.6],
    leftForeArm: [-1.5, 0, 0.5],
    leftHand: [0, 0, 1.0], // Palm up/shrug
    head: [0, 0, 0.15], 
  }),
  THINKING: createPose({
    rightArm: [-1.3, 0.3, -0.3],
    rightForeArm: [-2.1, 0, 0], 
    rightHand: [0.5, 0, 0], // Hand on chin
    leftArm: [0.4, 0, 0.4], 
    leftForeArm: [-1.8, 0, 0],
    head: [0.1, -0.15, 0],
  }),
  LOVE: createPose({
    rightArm: [-0.8, 0.5, -0.5], 
    rightForeArm: [-2.2, 0, 0],
    rightHand: [0, 0, 0],
    leftArm: [-0.8, -0.5, 0.5], 
    leftForeArm: [-2.2, 0, 0],
    leftHand: [0, 0, 0],
    head: [0.1, 0.1, -0.1]
  }),
  THANKS: createPose({
    rightArm: [-1.2, 0, -0.2], 
    rightForeArm: [-2.0, 0, -0.5], 
    rightHand: [0, 0, -0.5], // Palm flat near mouth
    leftArm: [0, 0, 0.15], 
    head: [0.2, 0, 0] 
  }),
  PLEASE: createPose({
    rightArm: [-1.0, 0.5, -0.4], 
    rightForeArm: [-1.8, 0, 0], 
    rightHand: [0, 0, -1.5], // Palm flat on chest
    leftArm: [0, 0, 0.15], 
    head: [0.1, 0, 0.1]
  }),
  SORRY: createPose({
    rightArm: [-1.0, 0.5, -0.4], 
    rightForeArm: [-2.0, 0, 0], 
    rightHand: [1.0, 0, 0], // Fist on chest
    leftArm: [0, 0, 0.15], 
    head: [0.2, 0, 0] 
  }),
  WELCOME: createPose({ 
    rightArm: [-0.5, 0, -1], 
    rightForeArm: [-0.5, 0, 0], 
    rightHand: [0, 0, -0.5],
    leftArm: [-0.5, 0, 1], 
    leftForeArm: [-0.5, 0, 0], 
    leftHand: [0, 0, 0.5],
    head: [0, 0, 0] 
  }),
  // --- Generic Conversation Gestures ---
  GENERIC_1: createPose({ 
    rightArm: [-0.6, 0.3, -0.4], rightForeArm: [-1.2, 0, 0], rightHand: [0, 0, -0.5],
    leftArm: [0, 0, 0.2], 
    head: [0, -0.1, 0] 
  }),
  GENERIC_2: createPose({ 
    rightArm: [-0.5, 0, -0.3], rightForeArm: [-1.0, 0, 0], rightHand: [0, 0, -1.0],
    leftArm: [-0.5, 0, 0.3], leftForeArm: [-1.0, 0, 0], leftHand: [0, 0, 1.0],
    head: [0, 0.1, 0] 
  }),
  GENERIC_3: createPose({ 
    rightArm: [-0.4, 0, -0.2], rightForeArm: [-0.5, 0, -0.2], rightHand: [0, 1.0, 0],
    leftArm: [0, 0, 0.2], 
    head: [0.1, 0, 0] 
  }),
  GENERIC_4: createPose({ 
    rightArm: [0, 0, -0.8], rightForeArm: [-0.5, 0, 0], rightHand: [0, 0, -0.5],
    leftArm: [0, 0, 0.8], leftForeArm: [-0.5, 0, 0], leftHand: [0, 0, 0.5],
    head: [0, 0, 0] 
  }),
  GENERIC_5: createPose({ 
    rightArm: [-0.8, 0, -0.5], rightForeArm: [-0.3, 0, 0], rightHand: [0, 0.5, 0],
    leftArm: [0, 0, 0.2], 
    head: [0, 0, -0.05]
  })
};

// --- Cartoon Style Colors ---
const skinColor = "#f5d0b0"; 
const hairColor = "#5d4037"; 
const sweaterColor = "#fdd835"; 

const Hand = ({ side }: { side: 'left' | 'right' }) => {
    return (
        <group>
            <mesh position={[0, -0.04, 0]}>
                 <boxGeometry args={[0.09, 0.11, 0.04]} />
                 <meshStandardMaterial color={skinColor} />
            </mesh>
            <mesh position={[0, -0.12, 0]}>
                 <boxGeometry args={[0.08, 0.08, 0.03]} />
                 <meshStandardMaterial color={skinColor} />
            </mesh>
            <mesh 
                position={[side === 'left' ? 0.06 : -0.06, -0.04, 0.02]} 
                rotation={[0, 0, side === 'left' ? -0.5 : 0.5]}
            >
                <capsuleGeometry args={[0.02, 0.08, 4, 8]} />
                <meshStandardMaterial color={skinColor} />
            </mesh>
        </group>
    )
}

const Head = ({ mood, blink }: { mood: string, blink: boolean }) => {
  return (
    <group position={[0, 1.5, 0]}>
      {/* Face */}
      <mesh position={[0, 0, 0]}>
        <sphereGeometry args={[0.35, 32, 32]} />
        <meshStandardMaterial color={skinColor} roughness={0.4} />
      </mesh>
      {/* Hair */}
      <group position={[0, 0.15, 0]}>
        <mesh position={[0, 0.15, -0.05]}>
           <sphereGeometry args={[0.36, 32, 32]} />
           <meshStandardMaterial color={hairColor} roughness={0.8} />
        </mesh>
        <mesh position={[0, 0.35, 0.1]} rotation={[-0.2, 0, 0]} scale={[1, 0.6, 1]}>
           <sphereGeometry args={[0.25, 32, 32]} />
           <meshStandardMaterial color={hairColor} roughness={0.8} />
        </mesh>
         <mesh position={[0.25, 0.1, 0.05]}>
           <sphereGeometry args={[0.12, 16, 16]} />
           <meshStandardMaterial color={hairColor} roughness={0.8} />
        </mesh>
         <mesh position={[-0.25, 0.1, 0.05]}>
           <sphereGeometry args={[0.12, 16, 16]} />
           <meshStandardMaterial color={hairColor} roughness={0.8} />
        </mesh>
      </group>
      {/* Beard */}
      <group>
        <mesh position={[0, -0.18, 0.08]} scale={[1.05, 1, 1]}>
             <sphereGeometry args={[0.34, 32, 32, 0, Math.PI * 2, 0, 1.3]} /> 
             <meshStandardMaterial color={hairColor} roughness={0.9} />
        </mesh>
        <mesh position={[0, -0.1, 0.32]} rotation={[0,0,1.57]}>
            <capsuleGeometry args={[0.04, 0.18, 4, 8]} />
            <meshStandardMaterial color={hairColor} roughness={0.9} />
        </mesh>
      </group>
      {/* Features */}
      <group position={[0, 0.05, 0.3]}>
        {/* Eyes */}
        {blink ? (
            <>
             <mesh position={[-0.11, 0, 0]} rotation={[0,0,1.57]}>
                <capsuleGeometry args={[0.015, 0.08, 4, 8]} />
                <meshStandardMaterial color="#333" />
            </mesh>
            <mesh position={[0.11, 0, 0]} rotation={[0,0,1.57]}>
                <capsuleGeometry args={[0.015, 0.08, 4, 8]} />
                <meshStandardMaterial color="#333" />
            </mesh>
            </>
        ) : (
            <>
            <mesh position={[-0.11, 0, 0]}>
                <sphereGeometry args={[0.04, 32, 32]} />
                <meshStandardMaterial color="#222" />
            </mesh>
            <mesh position={[0.11, 0, 0]}>
                <sphereGeometry args={[0.04, 32, 32]} />
                <meshStandardMaterial color="#222" />
            </mesh>
            <mesh position={[-0.09, 0.02, 0.035]}>
                <sphereGeometry args={[0.01, 8, 8]} />
                <meshStandardMaterial color="#fff" emissive="#fff" />
            </mesh>
            <mesh position={[0.13, 0.02, 0.035]}>
                <sphereGeometry args={[0.01, 8, 8]} />
                <meshStandardMaterial color="#fff" emissive="#fff" />
            </mesh>
            </>
        )}
        {/* Eyebrows */}
        <group position={[0, 0.14, 0]}>
           <mesh position={[-0.11, 0, 0]} rotation={[0, 0, 0.1]}>
              <capsuleGeometry args={[0.02, 0.1, 4, 8]} />
              <meshStandardMaterial color={hairColor} />
           </mesh>
           <mesh position={[0.11, 0, 0]} rotation={[0, 0, -0.1]}>
              <capsuleGeometry args={[0.02, 0.1, 4, 8]} />
              <meshStandardMaterial color={hairColor} />
           </mesh>
        </group>
        {/* Nose */}
        <mesh position={[0, -0.06, 0.05]}>
            <sphereGeometry args={[0.045, 16, 16]} />
            <meshStandardMaterial color="#f0bba0" />
        </mesh>
        {/* Mouth */}
        <group position={[0, -0.16, 0.04]}>
             <mesh rotation={[0, 0, 3.14]} position={[0, 0, 0]}>
                 <torusGeometry args={[0.06, 0.015, 16, 32, 3.14]} />
                 <meshStandardMaterial color="#fff" />
            </mesh>
             <mesh position={[0, 0.02, -0.01]} scale={[1, 0.5, 1]}>
                 <circleGeometry args={[0.05, 16]} />
                 <meshBasicMaterial color="#7a3e3e" />
            </mesh>
        </group>
      </group>
       {/* Ears */}
       <mesh position={[-0.34, 0, -0.05]} rotation={[0, 0.2, 0]}>
           <sphereGeometry args={[0.07, 16, 16]} />
           <meshStandardMaterial color={skinColor} />
       </mesh>
        <mesh position={[0.34, 0, -0.05]} rotation={[0, -0.2, 0]}>
           <sphereGeometry args={[0.07, 16, 16]} />
           <meshStandardMaterial color={skinColor} />
       </mesh>
    </group>
  );
}

const Arm = ({ side, forwardRef, forearmRef, handRef }: { side: 'left' | 'right', forwardRef: any, forearmRef: any, handRef: any }) => {
    return (
      <group position={[side === 'left' ? 0.42 : -0.42, 0.85, 0]} ref={forwardRef}>
         {/* Upper Arm */}
         <mesh position={[0, -0.15, 0]}>
             <cylinderGeometry args={[0.13, 0.12, 0.45, 32]} />
             <meshStandardMaterial color={sweaterColor} />
         </mesh>
         
         <group position={[0, -0.4, 0]} ref={forearmRef}>
             {/* Forearm */}
             <mesh position={[0, -0.15, 0]}>
                 <cylinderGeometry args={[0.11, 0.10, 0.35, 32]} />
                 <meshStandardMaterial color={sweaterColor} />
             </mesh>
             {/* Wrist/Hand Group */}
             <group position={[0, -0.42, 0]} ref={handRef}>
                 <Hand side={side} />
             </group>
         </group>
      </group>
    )
}

const Body = () => {
    return (
        <group position={[0, 0, 0]}>
             <mesh position={[0, 0.5, 0]}>
                 <RoundedBox args={[0.75, 0.85, 0.45]} radius={0.1} smoothness={8}>
                    <meshStandardMaterial color={sweaterColor} />
                 </RoundedBox>
             </mesh>
             <mesh position={[0, 0.88, 0]} rotation={[1.57, 0, 0]}>
                 <torusGeometry args={[0.15, 0.04, 16, 32]} />
                 <meshStandardMaterial color={sweaterColor} roughness={0.6} />
             </mesh>
        </group>
    )
}

const Character = ({ pose, mood, blink, currentSignName }: { pose: JointRotations, mood: string, blink: boolean, currentSignName: string }) => {
  const group = useRef<THREE.Group>(null);
  const headRef = useRef<THREE.Group>(null);
  const rightArmRef = useRef<THREE.Group>(null);
  const rightForeArmRef = useRef<THREE.Group>(null);
  const rightHandRef = useRef<THREE.Group>(null);
  const leftArmRef = useRef<THREE.Group>(null);
  const leftForeArmRef = useRef<THREE.Group>(null);
  const leftHandRef = useRef<THREE.Group>(null);

  useFrame((state, delta) => {
      const damp = (ref: any, target: number[]) => {
          if (!ref.current) return;
          ref.current.rotation.x = THREE.MathUtils.damp(ref.current.rotation.x, target[0], 8, delta);
          ref.current.rotation.y = THREE.MathUtils.damp(ref.current.rotation.y, target[1], 8, delta);
          ref.current.rotation.z = THREE.MathUtils.damp(ref.current.rotation.z, target[2], 8, delta);
      }
      
      const time = state.clock.elapsedTime;
      let targetRightArm = [...pose.rightArm];
      let targetRightForeArm = [...pose.rightForeArm];
      let targetRightHand = [...pose.rightHand];
      let targetLeftArm = [...pose.leftArm];
      let targetLeftForeArm = [...pose.leftForeArm];
      let targetLeftHand = [...pose.leftHand];
      let targetHead = [...pose.head];

      const breath = Math.sin(time * 2) * 0.02;
      targetRightArm[2] += breath;
      targetLeftArm[2] -= breath;
      targetHead[0] += breath * 0.5;

      if (currentSignName === 'HELLO') {
         targetRightForeArm[2] += Math.sin(time * 10) * 0.3;
         targetRightHand[2] += Math.sin(time * 10) * 0.2;
      }
      else if (currentSignName === 'NO') {
         targetHead[1] += Math.sin(time * 15) * 0.3;
         targetRightForeArm[1] += Math.sin(time * 15) * 0.2;
      }
      else if (currentSignName === 'YES' || currentSignName === 'THANKS') {
         targetHead[0] += Math.abs(Math.sin(time * 10)) * 0.2;
      }
      else if (currentSignName === 'QUESTION') {
         targetHead[2] += Math.sin(time * 2) * 0.1;
      }
      else if (currentSignName.startsWith('GENERIC')) {
         const intensity = 0.1;
         targetRightForeArm[0] += Math.sin(time * 5) * intensity;
         targetRightHand[0] += Math.cos(time * 5) * intensity;
         targetLeftForeArm[0] += Math.sin(time * 4) * intensity;
      }

      damp(headRef, targetHead);
      damp(rightArmRef, targetRightArm);
      damp(rightForeArmRef, targetRightForeArm);
      damp(rightHandRef, targetRightHand);
      damp(leftArmRef, targetLeftArm);
      damp(leftForeArmRef, targetLeftForeArm);
      damp(leftHandRef, targetLeftHand);
  });

  // Adjusted Y position to center upper body without legs
  return (
    <group ref={group} position={[0, -0.8, 0]}>
      <group ref={headRef}>
         <Head mood={mood} blink={blink} />
      </group>
      <Body />
      {/* Legs Removed */}
      <Arm side="right" forwardRef={rightArmRef} forearmRef={rightForeArmRef} handRef={rightHandRef} />
      <Arm side="left" forwardRef={leftArmRef} forearmRef={leftForeArmRef} handRef={leftHandRef} />
    </group>
  );
}

const Avatar: React.FC<AvatarProps> = ({ state, gloss, mood = 'neutral' }) => {
  const [currentPose, setCurrentPose] = useState<JointRotations>(POSES_3D.IDLE);
  const [currentSign, setCurrentSign] = useState<string>("");
  const [blink, setBlink] = useState(false);

  useEffect(() => {
     const interval = setInterval(() => {
         setBlink(true);
         setTimeout(() => setBlink(false), 150);
     }, 3000 + Math.random() * 2000);
     return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    let timeoutId: ReturnType<typeof setTimeout>;

    if (state === 'idle') {
       setCurrentPose(POSES_3D.IDLE);
       setCurrentSign("");
       return;
    }

    if (state === 'thinking') {
       setCurrentPose(POSES_3D.THINKING);
       return;
    }

    if (state === 'signing' && gloss && gloss.length > 0) {
      let index = 0;
      
      const playNextSign = () => {
        if (index >= gloss.length) {
          setCurrentSign("");
          setCurrentPose(POSES_3D.IDLE);
          return;
        }

        const word = gloss[index];
        setCurrentSign(word);

        const cleanWord = word.toUpperCase().replace(/[^A-Z]/g, '');

        let targetPose = POSES_3D[cleanWord] || POSES_3D[word];
        let signName = cleanWord;

        if (!targetPose) {
           const generics = [
             'GENERIC_1', 'GENERIC_2', 'GENERIC_3', 'GENERIC_4', 'GENERIC_5'
           ];
           let hash = 0;
           for (let i = 0; i < cleanWord.length; i++) {
               hash = cleanWord.charCodeAt(i) + ((hash << 5) - hash);
           }
           signName = generics[Math.abs(hash) % generics.length];
           targetPose = POSES_3D[signName];
        }

        setCurrentPose(targetPose);
        index++;
        timeoutId = setTimeout(playNextSign, 750);
      };

      playNextSign();
    }

    return () => clearTimeout(timeoutId);
  }, [state, gloss]);

  const getAnimationKey = (word: string) => {
      if (!word) return 'IDLE';
      const cleanWord = word.toUpperCase().replace(/[^A-Z]/g, '');
      if (POSES_3D[cleanWord] || POSES_3D[word]) return cleanWord;
      
      const generics = ['GENERIC_1', 'GENERIC_2', 'GENERIC_3', 'GENERIC_4', 'GENERIC_5'];
      let hash = 0;
      for (let i = 0; i < cleanWord.length; i++) {
          hash = cleanWord.charCodeAt(i) + ((hash << 5) - hash);
      }
      return generics[Math.abs(hash) % generics.length];
  }

  const animationKey = useMemo(() => getAnimationKey(currentSign), [currentSign]);

  return (
    <div className="relative w-full h-full flex flex-col items-center justify-center">
      {/* Gloss Overlay */}
      {state === 'signing' && currentSign && (
        <div className="absolute top-4 left-0 right-0 text-center z-20 pointer-events-none">
          <span className="bg-red-700/95 text-white px-8 py-3 rounded-full text-5xl font-black shadow-2xl animate-fade-in-up backdrop-blur-md border-4 border-red-500 tracking-wider">
            {currentSign}
          </span>
        </div>
      )}

      <div className="w-full h-full bg-gradient-to-b from-orange-50 to-stone-100 rounded-xl shadow-inner overflow-hidden relative border-2 border-stone-200">
        <Canvas camera={{ position: [0, 1.3, 4.5], fov: 45 }} shadows>
           <ambientLight intensity={0.9} color="#fff" />
           <hemisphereLight intensity={0.7} color="#fff" groundColor="#f0f0f0" />
           <spotLight position={[3, 5, 4]} angle={0.5} intensity={1.0} color="#fff" castShadow />
           <pointLight position={[-3, 2, 4]} intensity={0.6} color="#ffe" />
           
           <Float speed={2} rotationIntensity={0.05} floatIntensity={0.2}>
               <Character 
                  pose={currentPose} 
                  mood={mood} 
                  blink={blink} 
                  currentSignName={animationKey}
               />
           </Float>
           
           <ContactShadows opacity={0.3} scale={10} blur={2.5} far={10} resolution={256} color="#000000" />
        </Canvas>
      </div>
      
      <div className={`absolute bottom-3 right-3 px-5 py-3 rounded-xl text-base font-black tracking-widest uppercase shadow-lg transition-colors border-4 ${
        state === 'listening' ? 'bg-red-100 text-red-900 border-red-300' :
        state === 'signing' ? 'bg-green-100 text-green-900 border-green-300' :
        state === 'thinking' ? 'bg-yellow-100 text-yellow-900 border-yellow-400' :
        'bg-stone-100 text-stone-900 border-stone-300'
      }`}>
        {state === 'listening' && "Listening"}
        {state === 'thinking' && "Thinking"}
        {state === 'signing' && "Signing"}
        {state === 'idle' && "Ready"}
      </div>
    </div>
  );
};

export default Avatar;