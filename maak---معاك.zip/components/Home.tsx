import React from 'react';
import { ArrowRight, Globe, ExternalLink } from 'lucide-react';
import { translations, Language } from '../utils/translations';

interface HomeProps {
  lang: Language;
  onNavigate: (view: 'auth' | 'home' | 'app') => void;
}

const Home: React.FC<HomeProps> = ({ lang, onNavigate }) => {
  const t = translations[lang];
  const isRTL = lang === 'ar';

  return (
    <div className="flex-1 flex flex-col items-center justify-center p-6 space-y-8 animate-fade-in text-center max-w-lg mx-auto w-full">
      
      {/* Hero */}
      <div className="space-y-4">
        <div className="w-24 h-24 rounded-full bg-red-700 flex items-center justify-center text-white font-black text-4xl shadow-xl border-4 border-red-800 mx-auto mb-6">
           {lang === 'ar' ? 'م' : 'M'}
        </div>
        <h1 className="text-5xl font-black text-red-800 tracking-tight">{t.appName}</h1>
        <p className="text-2xl text-stone-600 font-medium">{t.welcomeSubtitle}</p>
      </div>

      {/* AVST Card */}
      <div className="bg-white p-8 rounded-[2rem] shadow-lg border-2 border-stone-200 w-full">
        <h2 className="text-3xl font-bold text-stone-900 mb-4">{t.avstTitle}</h2>
        <p className="text-xl text-stone-700 leading-relaxed mb-6">
          {t.avstDesc}
        </p>
        <a 
          href="https://www.avsttunisie.com/a-propos-de-lavst/" 
          target="_blank" 
          rel="noopener noreferrer"
          className="flex items-center justify-center space-x-2 space-x-reverse bg-stone-100 hover:bg-stone-200 text-stone-900 px-6 py-4 rounded-xl font-bold transition-all text-lg border border-stone-300"
          dir={isRTL ? 'rtl' : 'ltr'}
        >
          <span>{t.visitWebsite}</span>
          <ExternalLink size={20} className={isRTL ? 'mr-2' : 'ml-2'} />
        </a>
      </div>

      {/* CTA */}
      <button 
        onClick={() => onNavigate('auth')}
        className="w-full bg-red-700 hover:bg-red-800 text-white text-2xl font-black py-6 rounded-full shadow-xl hover:shadow-2xl transition-all transform hover:scale-[1.02] flex items-center justify-center space-x-3"
        dir={isRTL ? 'rtl' : 'ltr'}
      >
        <span>{t.getStarted}</span>
        {isRTL ? <ArrowRight size={28} className="rotate-180 mr-3" /> : <ArrowRight size={28} className="ml-3" />}
      </button>

    </div>
  );
};

export default Home;