import React, { useState, useEffect } from 'react';
import Home from './components/Home';
import Auth from './components/Auth';
import MainApp from './components/MainApp';
import { translations, Language } from './utils/translations';

function App() {
  const [lang, setLang] = useState<Language>('ar');
  const [view, setView] = useState<'home' | 'auth' | 'app'>('home');

  useEffect(() => {
    // Set direction based on language
    const dir = lang === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.dir = dir;
    document.documentElement.lang = lang;
  }, [lang]);

  const handleLanguageChange = (l: Language) => {
    setLang(l);
  };

  // Simple Router
  const renderView = () => {
    switch(view) {
      case 'home':
        return <Home lang={lang} onNavigate={setView} />;
      case 'auth':
        return <Auth lang={lang} onLogin={() => setView('app')} onBack={() => setView('home')} />;
      case 'app':
        return <MainApp lang={lang} onLogout={() => setView('home')} />;
      default:
        return <Home lang={lang} onNavigate={setView} />;
    }
  };

  return (
    <div className={`h-screen w-full bg-[#FFF8F0] font-sans text-stone-900 flex flex-col overflow-hidden ${lang === 'ar' ? 'font-cairo' : ''}`}>
      
      {/* Language Switcher (Visible on Home and Auth) */}
      {view !== 'app' && (
        <div className="absolute top-4 right-4 z-50 flex space-x-2 space-x-reverse rtl:space-x-reverse">
          {(['ar', 'fr', 'en'] as Language[]).map((l) => (
             <button
               key={l}
               onClick={() => handleLanguageChange(l)}
               className={`w-10 h-10 rounded-full font-bold text-sm transition-all border-2 ${
                 lang === l 
                 ? 'bg-red-700 text-white border-red-800 shadow-md transform scale-110' 
                 : 'bg-white text-stone-600 border-stone-300 hover:bg-stone-50'
               }`}
             >
               {l.toUpperCase()}
             </button>
          ))}
        </div>
      )}

      {renderView()}
    </div>
  );
}

export default App;