import { GoogleGenAI, Modality, Type } from "@google/genai";
import { SignGlossResponse } from "../types";

// Initialize Gemini Client
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Transcribes audio input (Tunisian Dialect) to Text using gemini-3-flash-preview.
 */
export const transcribeAudio = async (audioBase64: string, mimeType: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: mimeType,
              data: audioBase64,
            },
          },
          {
            text: "Transcribe this audio strictly. The audio is in Tunisian Dialect (Derja). Return only the transcribed text in Arabic script or Latin script (Arabizi) as spoken.",
          },
        ],
      },
    });
    return response.text || "";
  } catch (error) {
    console.error("Transcription error:", error);
    throw new Error("Failed to transcribe audio.");
  }
};

/**
 * Translates text (Tunisian Dialect) to Sign Language Gloss (Instructions for Avatar).
 * Uses gemini-3-flash-preview.
 */
export const translateToSignGloss = async (text: string): Promise<SignGlossResponse> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Translate the following Tunisian Dialect sentence into Tunisian Sign Language (TSL) Gloss.
      Input text: "${text}"
      
      Return a JSON object with:
      - gloss: An array of uppercase strings representing the sign order (TSL grammar).
      - description: A short visual description of the signs/movements for an avatar to perform.
      - tunisianText: The original text normalized.
      - mood: The emotional tone of the sentence (neutral, happy, questioning, concerned).
      
      Example Input: "Chnoua a7walek?" (How are you?)
      Example Output: { "gloss": ["HELLO", "YOU", "GOOD", "QUESTION"], "description": "Wave hand, point to viewer, thumbs up, look inquisitive.", "tunisianText": "Chnoua a7walek?", "mood": "questioning" }`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            gloss: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            description: { type: Type.STRING },
            tunisianText: { type: Type.STRING },
            mood: { type: Type.STRING, enum: ['neutral', 'happy', 'questioning', 'concerned'] }
          }
        }
      }
    });

    const jsonText = response.text || "{}";
    return JSON.parse(jsonText) as SignGlossResponse;
  } catch (error) {
    console.error("Gloss translation error:", error);
    return {
      gloss: ["ERROR", "TRANSLATION"],
      description: "Shrug shoulders indicating error.",
      tunisianText: text,
      mood: 'concerned'
    };
  }
};

/**
 * Analyzes video (Sign Language) and translates to Text using gemini-3-pro-preview.
 */
export const interpretSignVideo = async (videoBase64: string, mimeType: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: mimeType,
              data: videoBase64,
            },
          },
          {
            text: "You are an expert interpreter of Tunisian Sign Language. Analyze this video and translate the signs performed into spoken Tunisian Dialect (Derja) text. Output ONLY the translation.",
          },
        ],
      },
    });
    return response.text || "Could not interpret video.";
  } catch (error) {
    console.error("Video interpretation error:", error);
    throw new Error("Failed to interpret video.");
  }
};

/**
 * Generates speech (TTS) from text using gemini-2.5-flash-preview-tts.
 * Used for the Deaf -> Hearing mode output.
 */
export const generateSpeech = async (text: string): Promise<string | null> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: 'Kore' }, // Using a clear voice
          },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (base64Audio) {
      return base64Audio;
    }
    return null;
  } catch (error) {
    console.error("TTS error:", error);
    return null;
  }
};
